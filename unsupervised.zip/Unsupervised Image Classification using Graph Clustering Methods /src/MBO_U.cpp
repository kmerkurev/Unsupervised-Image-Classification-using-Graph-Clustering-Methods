// This program is free software: you can use, modify and/or redistribute it
// under the terms of the simplified BSD License. You should have received a
// copy of this license along this program. If not, see
// <http://www.opensource.org/licenses/bsd-license.html>.
//
// Copyright (C) 2017 Zhaoyi Meng <mzhy@ucla.edu>
// All rights reserved.

#include "MBO_U.h"
#include <time.h>
#include <cmath>
#include <cstdlib>
#include <vector>
#include <iostream>
#include <cblas.h>

using namespace std;

MBO_U::MBO_U(){};
MBO_U::~MBO_U(){};

// x and c has same number of cols. result is a matrix with dimension x_row
// by c_row. the i,j element of result is ||x_i-c_j||^2, which is the
// Euclidean distance of the ith row of x and the jth row of c.
void dist2(double* x, double* c, double* result, int &x_row, int &x_col,
           int &c_row, int &c_col){
    int incx = 1;
    int len = x_row*c_row;
    double alpha = 1.0;
    double theta = -2.0;
    double beta = 0.0;
    // ||x||^2
    double * tempx = new double[len];
    
    for(int i=0; i<x_row; i++){
        double norm = cblas_dnrm2(x_col,x+i*x_col,incx);
        for(int j=0; j<c_row; j++){
            tempx[i*c_row+j] = norm;
        }
    }
    // x*y^T
    double * tempxy = new double[x_row*c_row];
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasTrans, x_row, c_row,
                x_col, alpha, x, x_col, c, x_col, beta, tempxy, c_row);
    
    //  ||c||^2
    for(int i=0; i<c_row; i++){
        double norm2 = cblas_dnrm2(c_col,c+i*c_col,incx);
        for(int j=0; j<x_row; j++){
            result[j*c_row+i] = norm2;
        }
    }
    cblas_daxpy(len,alpha,tempx,incx,result,incx);
    cblas_daxpy(len,theta,tempxy,incx,result,incx);
    delete [] tempx;
    delete [] tempxy;
}

//f is a rows by cols matrix, index is a rows by 1 matrix, we find
//the largest element in each row of f and put its index in Index.
void MBO_U::get_index(double *Index, double *f,int rows,int cols){
    for(int i = 0; i<rows; i++){
        Index[i] = 0;
        double max = f[i*cols];
        for(int j = 0; j<cols; j++){
            if(max<f[i*cols+j]){
                max = f[i*cols+j];
                Index[i] = j;
            }
        }
    }
}
// calculate the purity score between two vectors
double MBO_U::puritymeas(double * index, double * preindex, int len,
                         int num_class){
    double score = 0;
    double avgscore = 0;
    for(int i = 0; i< num_class; i++){
        int pos = 0;
        std::vector<double> ind;
        for(int j = 0; j<len; j++){
            if(index[j] == i){
                ind.push_back(pos);
            }
            pos++;
        }
        int count = 0;
        int vec_length = ind.size();
        for(int k = 0; k<vec_length; k++){
            int temp = ind.at(k);
            if(preindex[temp]==i)
                count++;
        }
        score = score + count;
    }
    avgscore = score/len;
    return avgscore;
}

void MBO_U::Mumford_Shah(double * index, double * f,
                         double * X, double * Lambda, int N, int n,
                         int M, int d, double dt, double mu){
    double alpha = 1.0;
    double beta = 0.0;
    int incx = 1;
    
    // initialize u^0
    double * u = new double [N*n];
    double * preindex = new double [N];
    for(int i = 0; i<N*n; i++){
        u[i] = 0;
    }
    for(int i = 0; i<N; i++){
        int randint = rand()%n;
        index[i] = randint;
        int x = i*n+randint;
        u[x] = 1;
    }
    cblas_dcopy(N,index,incx,preindex,incx);
    //initialize a^0, compute a^0 via (11); a^0 = X^T * u^0
    double * a =new double[M*n];
    
    cblas_dgemm(CblasRowMajor, CblasTrans, CblasNoTrans,
                M, n, N, alpha, X, M, u, n, beta, a, n);
    // One_minus_dt_Lambda = 1-dt*Lambda
    double * One_minus_dt_Lambda = new double[M];
    for(int i = 0; i<M ; i++){
        One_minus_dt_Lambda[i] = 1.0 - dt*Lambda[i];
    }
    
    int flag = 1;
    int iter = 1;
    
    double * u1 = new double[N*n];
    double * c = new double[n*d];
    double * u_column_sum = new double[n];
    double * u2 = new double[N*n];
    
    while(flag){
        // updating c via (20)
        // c = u^T * f
        cblas_dgemm(CblasRowMajor, CblasTrans, CblasNoTrans,n, d, N,
                    alpha, u, n, f, d, beta, c, d);
        
        //  u_column_sum = <1,u>; number of nodes in each class
        for(int i=0; i<n; i++){
            u_column_sum[i] = 0;
        }
        for(int i=0; i<N; i++){
            int idx = index[i];
            u_column_sum[idx] += 1;
        }
        // c = c / <1,u>
        for(int i = 0; i<n; i++){
            for(int j = 0; j<d; j++){
                c[i*d+j] = c[i*d+j]/u_column_sum[i];
            }
        }

        // compute u^{n+1/2} via (21)
        // a = (1 - dt * Lambda) * a
        for(int i = 0; i<M; i++){
            for(int j = 0; j<n; j++){
                a[i*n+j] = a[i*n+j]*One_minus_dt_Lambda[i];
            }
        }
        //u1 = X*a
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
                    N, n, M, alpha, X, M, a, n, beta, u1, n);
       
        // u2 = (||f-c_1||^2,...,||f-c_n||^2)
        dist2(f,c,u2,N,d,n,d);
        
        //u1 = -dt*mu*u2+u1;
        int f_len = N*n;
        double gamma = -dt*mu;
        cblas_daxpy(f_len,gamma,u2,incx,u1,incx);
        get_index(index,u1,N,n);
        
        // u_i^{n+1} = e_r, where e_r = argmax(u_i^{n+1/2})
        for(int i = 0; i<N*n; i++){
            u[i] = 0;
        }
        for(int i = 0; i<N; i++){
            int x = i*n+index[i];
            u[x]= 1;
        }
        
        // compute a^{n+1} via (11); a = X^T*u
        cblas_dgemm(CblasRowMajor, CblasTrans, CblasNoTrans,M, n, N,
                    alpha, X, M, u, n, beta, a, n);
        
        //stopping creteria
        double purity_score = puritymeas(index,
                                              preindex, N, n);
        iter = iter + 1;
        
        if(purity_score>0.999){
            flag = 0;
        }
        // preindex = index
        cblas_dcopy(N,index,incx,preindex,incx);
    }
    
    //deallocate
    delete [] preindex;
    delete [] u;
    delete [] a;
    delete [] One_minus_dt_Lambda;
    delete [] u1;
    delete [] c;
    delete [] u_column_sum;
    delete [] u2;
}

// This program is free software: you can use, modify and/or redistribute it
// under the terms of the simplified BSD License. You should have received a
// copy of this license along this program. If not, see
// <http://www.opensource.org/licenses/bsd-license.html>.
//
// Copyright (C) 2017 Zhaoyi Meng <mzhy@ucla.edu>
// All rights reserved.

#include <time.h>
#include <iostream>
#include <cmath>
#include <fstream>
#include <cstdlib>
#include <sstream>
#include "Nystrom.h"
#include "MBO_U.h"
#include "FeatureVec.h"
extern "C" {
#include "iio.h"
}
using namespace std;

void normalize(double * A, int rows, int cols){
    for(int i = 0; i<rows; i++){
        double sum(0);
        for(int j = 0; j<cols; j++){
            sum = sum + A[i*cols+j]*A[i*cols+j];
        }
        double norm(0);
        norm = sqrt(sum);
        for(int j = 0; j<cols; j++){
            A[i*cols+j] = A[i*cols+j]/norm;
        }
    }
}

int main(int argc, const char * argv[]) {
    if (argc<6) {
        cout << "Not enough input parameters"<<endl;
        printf("Usage: %s n dt mu sigma input_image_string \n", argv[0]);
    } else {
        srand(time(NULL));
        
        int n = atoi(argv[1]);        //number of classes
        double dt = atof(argv[2]);
        double mu = atof(argv[3])*100000.0;
        double sigma = atof(argv[4]);
        string input_img_string(argv[5]);  //input image
        int m = 100;
        
        // read in image
	ifstream infile(input_img_string.c_str());
        if (!infile.good()) {
            cout << "Error Opening File"<<endl;
            return 0;
        }        

        int width;
        int height;
        int d;
        double * input_image;
        input_image = iio_read_image_double_vec(input_img_string.c_str(),
                                                &width,&height,&d);
        // add a small number to all the pixel values in case there are a lot of 0s
        for (int i=0; i<width*height*d; i++) {
            input_image[i] += 0.1;
        }
        double * feature_vec;
        
        // if the number of channels of the image is small, we use the nonlocal means method
        // to build the feature vector of each pixel.
        if (d<4) {
            // for RGB image, rescale some parameters so that it is more
            // consistant with the hyperspectral image
            sigma = sigma * 100.0;
            mu = mu / 100.0;
            // for RGB image, need to read frame by frame
            double * input_image_split = new double [width*height*d];
            for (int i=0; i<width*height; i++) {
                for (int l=0; l<d; l++) {
                    input_image_split[width*height*l+i] = input_image[d*i+l];
                }
            }
            // use non-local means method to build the feature vector
            int windowSize = 2;
            FeatureVec Feature_obj;
            double * kernel = new double[(2*windowSize+1)*(2*windowSize+1)];
            for (int i=0; i<(2*windowSize+1)*(2*windowSize+1); i++) {
                kernel[i] = 0;
            }
            Feature_obj.makeKernel(kernel,windowSize);
            
            int N1p = height + 2 * windowSize;
            int N2p = width + 2 * windowSize;
            double* padimage = new double[N1p*N2p*d];
            for (int i=0; i<N1p*N2p*d; i++) {
                padimage[i] = 0;
            }
            Feature_obj.padarray(input_image_split,padimage,windowSize,
                                 height,width,d);
            
            int size_feature = width*height*(2*windowSize+1)*(2*windowSize+1)*3;
            feature_vec = new double[size_feature];
            
            Feature_obj.makeFeatureVec(feature_vec,padimage,kernel,
                                       windowSize,height,width,d);
            d = (2*windowSize+1)*(2*windowSize+1)*d;
            delete [] kernel;
            delete [] input_image_split;
            delete [] padimage;
        } else {
            cout << "Hyperspectral Image"<<endl;
            feature_vec = input_image;
        }
        int N = width*height;
       
        // Nystrom
        cout << "start Nystrom algorithm"<<endl;
        double * X = new double [N*m];
        double * D = new double [m];
        
        Nystrom N_obj;
        N_obj.Nystrom_algorithm(feature_vec,m,sigma,N,d,X,D);
        cout << "end Nystrom algorithm"<<endl;
        
        // unsupervised MBO algorithm
        cout << "start unsupervised MBO algorithm"<<endl;
        normalize(feature_vec, N, d);
        double * index = new double [N];
        MBO_U MS_obj;
        MS_obj.Mumford_Shah(index,feature_vec,X,D,N,n,m,d,dt,mu);
        cout << "end unsupervised MBO algorithm"<<endl;
        
        // write result
        ofstream final;
        final.open("classification_result.txt");
        for (int i=0; i<N; i++) {
            final << index[i] << "\r\n";
        }
        final<<"\r\n\n";
        
        // Free momeries
        if (d<4) {
            delete [] feature_vec;
        }
        delete input_image;
        delete [] X;
        delete [] D;
    }
    
    return 0;
}
